var a=13;
var b=18;
var c= a+b;
console.log("A = "+a);
console.log("B = "+b);
console.log("Sum = "+c);