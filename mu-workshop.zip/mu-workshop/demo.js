var a=13;
var b=18;
var c= a+b;
console.log(`Sum of ${a} and ${b} is ${c}`);
console.log( `
Sum of 
${a} and ${b} 
is${c}`);