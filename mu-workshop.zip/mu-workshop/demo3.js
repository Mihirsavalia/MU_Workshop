var a=13;
var b=18;
var c= a+b;
console.log("A = "+a);
console.log("B = "+b);
console.log("Sum = "+c);

if(a==13)
    console.log("A Is Equal to 13");

for(var i=1;i<=10;i++)
    console.log(i);