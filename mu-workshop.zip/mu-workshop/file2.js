var msg = require('./file1');
console.log(msg);